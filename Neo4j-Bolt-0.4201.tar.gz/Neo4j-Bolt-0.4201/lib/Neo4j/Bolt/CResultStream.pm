package
  Neo4j::Bolt::CResultStream;
BEGIN {
  our $VERSION = "0.4201";
  require XSLoader;
  XSLoader::load();
}
1;
