package
  Neo4j::Bolt::ResultStreamC;
BEGIN {
  our $VERSION = "0.40";
  require XSLoader;
  XSLoader::load();
}
1;
