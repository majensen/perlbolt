package
  Neo4j::Bolt::CResultStream;
BEGIN {
  our $VERSION = "0.5000";
  require XSLoader;
  XSLoader::load();
}
1;
