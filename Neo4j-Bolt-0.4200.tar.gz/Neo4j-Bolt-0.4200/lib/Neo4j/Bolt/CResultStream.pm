package
  Neo4j::Bolt::CResultStream;
BEGIN {
  our $VERSION = "0.4200";
  require XSLoader;
  XSLoader::load();
}
1;
