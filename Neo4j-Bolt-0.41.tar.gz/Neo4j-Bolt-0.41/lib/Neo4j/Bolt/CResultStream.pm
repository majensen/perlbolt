package
  Neo4j::Bolt::CResultStream;
BEGIN {
  our $VERSION = "0.41";
  require XSLoader;
  XSLoader::load();
}
1;
